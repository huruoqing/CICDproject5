## Command line options

| Option    | Description                        | Default       |
|-----------|------------------------------------|---------------|
|`--fortune`| Fortune file, one fortune per line | ./fortune.txt |
|`--static` | Static assets directory            | ./static      |
|`--port`   | Port to bind to                    | 3000          |

